import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Review } from '../types';

interface ReviewState {
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'date'>) => void;
  getReviewsByProductId: (productId: string) => Review[];
  getAverageRating: (productId: string, initialRating: number, initialReviews: number) => { rating: number, count: number };
}

export const useReviewStore = create<ReviewState>()(
  persist(
    (set, get) => ({
      reviews: [
        {
          id: 'r1',
          productId: 'purse-001',
          userName: 'Sarah M.',
          rating: 5,
          comment: 'Absolutely love this bag! The embroidery is even more beautiful in person.',
          date: '2024-03-15'
        },
        {
          id: 'r2',
          productId: 'purse-001',
          userName: 'Priya K.',
          rating: 4,
          comment: 'Very elegant and spacious. The quality is top-notch.',
          date: '2024-03-10'
        }
      ],
      addReview: (reviewData) => {
        const newReview: Review = {
          ...reviewData,
          id: Math.random().toString(36).substr(2, 9),
          date: new Date().toISOString().split('T')[0]
        };
        set((state) => ({
          reviews: [newReview, ...state.reviews]
        }));
      },
      getReviewsByProductId: (productId) => {
        return get().reviews.filter((r) => r.productId === productId);
      },
      getAverageRating: (productId, initialRating, initialReviews) => {
        const productReviews = get().reviews.filter((r) => r.productId === productId);
        if (productReviews.length === 0) return { rating: initialRating, count: initialReviews };
        
        const totalRating = productReviews.reduce((acc, curr) => acc + curr.rating, 0);
        // We simulate the average by combining initial rating with new reviews
        // For a more realistic "mock", we'll just use the new reviews if they exist
        // or a weighted average. Let's do a weighted average.
        const newCount = productReviews.length;
        const avg = totalRating / newCount;
        
        return { 
          rating: parseFloat(avg.toFixed(1)), 
          count: initialReviews + newCount 
        };
      }
    }),
    {
      name: 'product-reviews',
    }
  )
);
