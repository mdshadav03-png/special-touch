import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Order, CartItem, ShippingDetails, OrderStatus } from '../types';

interface OrderState {
  orders: Order[];
  addOrder: (items: CartItem[], totalAmount: number, shipping: ShippingDetails, paymentMethod: 'COD' | 'ONLINE') => string;
  updateOrderStatus: (orderId: string, status: OrderStatus, location: string, description: string) => void;
}

export const useOrderStore = create<OrderState>()(
  persist(
    (set) => ({
      orders: [],
      addOrder: (items, totalAmount, shipping, paymentMethod) => {
        const orderId = `ORD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
        const now = new Date().toISOString();
        
        // Estimated delivery: 3 days from now
        const deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + 3);

        const newOrder: Order = {
          id: orderId,
          items: [...items],
          totalAmount,
          date: now,
          status: 'Processing',
          shipping,
          paymentMethod,
          estimatedDelivery: deliveryDate.toISOString(),
          trackingHistory: [
            {
              status: 'Processing',
              timestamp: now,
              location: 'Warehouse Center',
              description: 'Order confirmed and being prepared for dispatch.'
            }
          ]
        };
        set((state) => ({
          orders: [newOrder, ...state.orders],
        }));
        return orderId;
      },
      updateOrderStatus: (orderId, status, location, description) => {
        set((state) => ({
          orders: state.orders.map((order) => 
            order.id === orderId 
              ? { 
                  ...order, 
                  status, 
                  trackingHistory: [
                    { status, timestamp: new Date().toISOString(), location, description },
                    ...order.trackingHistory
                  ] 
                } 
              : order
          )
        }));
      }
    }),
    {
      name: 'order-storage',
    }
  )
);
