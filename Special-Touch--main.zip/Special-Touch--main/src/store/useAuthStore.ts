import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ShippingDetails } from '../types';

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  joinDate: string;
  savedAddresses?: ShippingDetails[];
}

interface AuthState {
  user: UserProfile | null;
  updateProfile: (profile: Partial<UserProfile>) => void;
  addAddress: (address: ShippingDetails) => void;
  removeAddress: (index: number) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: {
        name: 'Special Touch User',
        email: 'mdshadav03@gmail.com',
        phone: '+91 9999999999',
        joinDate: new Date().toISOString(),
        savedAddresses: [],
      },
      updateProfile: (profile) => 
        set((state) => ({
          user: state.user ? { ...state.user, ...profile } : null
        })),
      addAddress: (address) =>
        set((state) => ({
          user: state.user 
            ? { 
                ...state.user, 
                savedAddresses: [...(state.user.savedAddresses || []), address] 
              } 
            : null
        })),
      removeAddress: (index) =>
        set((state) => ({
          user: state.user
            ? {
                ...state.user,
                savedAddresses: (state.user.savedAddresses || []).filter((_, i) => i !== index)
              }
            : null
        })),
      logout: () => set({ user: null }),
    }),
    {
      name: 'auth-storage',
    }
  )
);
