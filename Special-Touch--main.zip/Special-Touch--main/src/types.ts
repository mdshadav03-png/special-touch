export interface Review {
  id: string;
  productId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice: number;
  discount: number;
  category: string;
  rating: number;
  reviews: number;
  images: string[];
  features: string[];
  sku?: string;
  color?: string;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export interface ShippingDetails {
  fullName: string;
  phone: string;
  address: string;
  city: string;
  pincode: string;
}

export type OrderStatus = 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered' | 'Cancelled';

export interface TrackingEvent {
  status: OrderStatus;
  timestamp: string;
  location: string;
  description: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  totalAmount: number;
  date: string;
  status: OrderStatus;
  shipping: ShippingDetails;
  paymentMethod: 'COD' | 'ONLINE';
  trackingHistory: TrackingEvent[];
  estimatedDelivery?: string;
}
