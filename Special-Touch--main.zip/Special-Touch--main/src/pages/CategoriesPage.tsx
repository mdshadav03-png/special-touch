import React from 'react';
import { CATEGORIES, PRODUCTS } from '../data/products';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export function CategoriesPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-heading text-gray-900 mb-8 px-2">Shop by Category</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {CATEGORIES.map((cat) => (
          <Link 
            key={cat.id} 
            to={`/category/${cat.name}`}
            className="flex items-center p-4 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="w-20 h-20 bg-gray-50 rounded-xl flex items-center justify-center p-2 mr-4 group-hover:bg-brand-pink/5 transition-colors">
              <img 
                src={PRODUCTS.find(p => p.category === cat.name)?.images[0] || 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=200'}
                alt={cat.name}
                className="w-16 h-16 object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-900 text-lg">{cat.name}</h3>
              <p className="text-gray-500 text-xs">
                {PRODUCTS.filter(p => p.category === cat.name).length} Products
              </p>
            </div>
            <ChevronRight className="text-gray-300 group-hover:text-brand-pink transition-colors" />
          </Link>
        ))}
      </div>
    </div>
  );
}
