import { useCartStore } from '../store/useCartStore';
import { Minus, Plus, Trash2, ArrowLeft, ShieldCheck, ShoppingBag as ShoppingBagIcon } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { motion } from 'motion/react';
import { SafeImage } from '../components/SafeImage';

export function CartPage() {
  const { cart, removeFromCart, updateQuantity, getTotalPrice, getTotalItems } = useCartStore();
  const navigate = useNavigate();

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="mb-6 inline-flex p-6 bg-gray-50 rounded-full">
           <ShoppingBagIcon size={48} className="text-gray-300" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Cart is Empty</h2>
        <p className="text-gray-500 mb-8">Add something to make it happy!</p>
        <Link to="/">
          <Button className="bg-brand-pink text-white rounded-lg px-8">Continue Shopping</Button>
        </Link>
      </div>
    );
  }

  const handleCheckout = () => {
    navigate('/checkout');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-8 flex items-center">
        Shopping Cart <span className="ml-2 text-gray-400 font-normal">({getTotalItems()} Items)</span>
      </h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left: Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => (
            <motion.div
              layout
              key={item.id}
              className="bg-white p-4 rounded-xl border border-gray-100 flex gap-4"
            >
              <div className="w-24 h-32 bg-gray-50 rounded-lg overflow-hidden shrink-0">
                <SafeImage src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
              </div>
              
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-gray-900 line-clamp-1 mr-2">{item.name}</h3>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Size: Free Size</p>
                </div>

                <div className="flex items-end justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                       <span className="font-bold text-gray-900">₹{item.price}</span>
                       <span className="text-xs text-gray-400 line-through">₹{item.originalPrice}</span>
                    </div>
                  </div>

                  <div className="flex items-center border border-gray-200 rounded-md">
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-2 text-gray-500 hover:bg-gray-50"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="px-3 text-sm font-bold">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-2 text-gray-500 hover:bg-gray-50"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
          
          <Link to="/" className="inline-flex items-center text-brand-pink font-bold text-sm hover:underline py-4">
            <ArrowLeft size={16} className="mr-2" /> Add More Products
          </Link>
        </div>

        {/* Right: Summary */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-6 border-b border-gray-50 pb-4">Order Details</h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Total Product Price</span>
                <span>₹{getTotalPrice()}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>Total Discounts</span>
                <span className="text-green-600">-₹0</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>Shipping Charges</span>
                <span className="text-tag-blue">FREE</span>
              </div>
            </div>

            <div className="flex justify-between text-lg font-bold text-gray-900 border-t border-gray-50 pt-4 mb-8">
              <span>Order Total</span>
              <span>₹{getTotalPrice()}</span>
            </div>

            <Button 
               onClick={handleCheckout}
               className="w-full h-12 bg-brand-pink hover:bg-brand-pink/90 text-white font-bold rounded-lg shadow-lg shadow-brand-pink/20"
            >
              Place Order
            </Button>
            
            <div className="mt-6 p-3 bg-gray-50 rounded-lg flex items-center justify-center space-x-2">
               <ShieldCheck size={16} className="text-gray-400" />
               <span className="text-[10px] font-bold text-gray-400 tracking-wider">100% SAFE & SECURE PAYMENTS</span>
            </div>
          </div>
          
          <div className="text-center">
             <img src="https://trust-logos.s3.amazonaws.com/pci-dss-compliance.png" className="h-8 grayscale opacity-50 inline-block" />
          </div>
        </div>
      </div>
    </div>
  );
}
