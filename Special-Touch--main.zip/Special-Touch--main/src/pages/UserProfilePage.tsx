import { motion } from 'motion/react';
import { User, Mail, Phone, Calendar, ChevronRight, Settings, Shield, Bell, MapPin, Camera, Edit2, Trash2 } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export function UserProfilePage() {
  const { user, updateProfile, removeAddress } = useAuthStore();
  const navigate = useNavigate();

  if (!user) {
    navigate('/');
    return null;
  }

  const sections = [
    {
      title: 'Account Settings',
      items: [
        { icon: User, label: 'Edit Profile', action: () => toast.info('Edit profile coming soon!') },
        { icon: Bell, label: 'Notifications', action: () => toast.info('Notification settings coming soon!') },
      ]
    },
    {
      title: 'Privacy & Support',
      items: [
        { icon: Shield, label: 'Privacy Policy', action: () => toast.info('Privacy policy view') },
        { icon: Settings, label: 'App Settings', action: () => toast.info('App settings') },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header Profile Section */}
      <div className="bg-brand-pink pt-20 pb-12 px-6 rounded-b-[40px] shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-brand-teal/20 rounded-full -ml-16 -mb-16 blur-2xl" />
        
        <div className="relative flex flex-col items-center">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-4 border-white/50 bg-white/20 flex items-center justify-center overflow-hidden">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <User size={48} className="text-white" />
              )}
            </div>
            <button className="absolute bottom-0 right-0 p-2 bg-white rounded-full shadow-lg text-brand-pink hover:scale-110 transition-transform">
              <Camera size={16} />
            </button>
          </div>
          
          <h1 className="text-2xl font-bold text-white mt-4">{user.name}</h1>
          <p className="text-white/80 text-sm mt-1">{user.email}</p>
          
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="mt-6 px-6 py-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-full text-white text-sm font-bold flex items-center gap-2 hover:bg-white/30 transition-colors"
          >
            <Edit2 size={14} />
            Edit Profile
          </motion.button>
        </div>
      </div>

      {/* Info Cards */}
      <div className="max-w-2xl mx-auto px-6 -mt-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex justify-between items-center">
          <div className="flex flex-col items-center flex-1 border-r border-gray-100">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Joined</span>
            <span className="text-sm font-bold text-gray-900 mt-1">
              {new Date(user.joinDate).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}
            </span>
          </div>
          <div className="flex flex-col items-center flex-1 border-r border-gray-100">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Orders</span>
            <span className="text-sm font-bold text-gray-900 mt-1">12</span>
          </div>
          <div className="flex flex-col items-center flex-1">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Reviews</span>
            <span className="text-sm font-bold text-gray-900 mt-1">5</span>
          </div>
        </div>
      </div>

      {/* Details Lists */}
      <div className="max-w-2xl mx-auto px-6 mt-8 space-y-6">
        {/* Contact Info */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-50 bg-gray-50/50">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Contact Information</h2>
          </div>
          <div className="divide-y divide-gray-50">
            <div className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-500">
                <Mail size={18} />
              </div>
              <div>
                <p className="text-[10px] text-gray-400 font-bold uppercase">Email Address</p>
                <p className="text-sm font-medium text-gray-900">{user.email}</p>
              </div>
            </div>
            <div className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center text-green-500">
                <Phone size={18} />
              </div>
              <div>
                <p className="text-[10px] text-gray-400 font-bold uppercase">Phone Number</p>
                <p className="text-sm font-medium text-gray-900">{user.phone}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Saved Addresses Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-50 bg-gray-50/50 flex justify-between items-center">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Saved Addresses</h2>
            <span className="text-[10px] bg-brand-pink/10 text-brand-pink px-2 py-0.5 rounded-full font-bold">
              {user.savedAddresses?.length || 0} Saved
            </span>
          </div>
          <div className="divide-y divide-gray-50">
            {user.savedAddresses && user.savedAddresses.length > 0 ? (
              user.savedAddresses.map((addr, idx) => (
                <div key={idx} className="p-4 flex items-start justify-between group">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-pink-50 flex items-center justify-center text-brand-pink mt-1">
                      <MapPin size={18} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-900">{addr.fullName}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{addr.address}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5 uppercase font-bold tracking-tight">
                        {addr.city}, {addr.pincode}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Phone size={10} className="text-gray-400" />
                        <span className="text-[10px] font-medium text-gray-500">{addr.phone}</span>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                        removeAddress(idx);
                        toast.error('Address removed');
                    }}
                    className="p-2 text-gray-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))
            ) : (
              <div className="p-8 text-center">
                <MapPin size={32} className="text-gray-200 mx-auto mb-2" />
                <p className="text-sm text-gray-400">No saved addresses yet</p>
              </div>
            )}
          </div>
        </div>

        {/* Menu Sections */}
        {sections.map((section) => (
          <div key={section.title} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-4 border-b border-gray-50 bg-gray-50/50">
              <h2 className="text-xs font-bold text-gray-400 uppercase tracking-widest">{section.title}</h2>
            </div>
            <div className="divide-y divide-gray-50">
              {section.items.map((item) => (
                <button
                  key={item.label}
                  onClick={item.action}
                  className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-500 group-hover:text-brand-pink transition-colors">
                      <item.icon size={18} />
                    </div>
                    <span className="text-sm font-medium text-gray-900">{item.label}</span>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-brand-pink transition-colors" />
                </button>
              ))}
            </div>
          </div>
        ))}

        <button className="w-full p-4 bg-red-50 rounded-2xl text-red-600 text-sm font-bold hover:bg-red-100 transition-colors mt-4">
          Logout Account
        </button>
      </div>
    </div>
  );
}
