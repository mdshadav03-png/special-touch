import React, { useState, useEffect } from 'react';
import { useCartStore } from '../store/useCartStore';
import { useOrderStore } from '../store/useOrderStore';
import { useAuthStore } from '../store/useAuthStore';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { toast } from 'sonner';
import { ShieldCheck, ArrowLeft, MapPin, Check, Plus } from 'lucide-react';
import { ShippingDetails } from '../types';
import { cn } from '../lib/utils';

export function CheckoutPage() {
  const { cart, getTotalPrice, clearCart } = useCartStore();
  const { addOrder } = useOrderStore();
  const { user, addAddress } = useAuthStore();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'ONLINE'>('COD');
  const [saveAddressEnabled, setSaveAddressEnabled] = useState(true);
  const [showSavedAddresses, setShowSavedAddresses] = useState(false);
  const [formData, setFormData] = useState<ShippingDetails>({
    fullName: '',
    phone: '',
    address: '',
    city: '',
    pincode: '',
  });

  const [isSuccess, setIsSuccess] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState('');

  const [onlineTab, setOnlineTab] = useState<'QR' | 'APP'>('QR');

  useEffect(() => {
    if (cart.length === 0 && !isSuccess) {
      navigate('/cart');
    }
  }, [cart.length, navigate, isSuccess]);

  if (cart.length === 0 && !isSuccess) {
    return null;
  }

  const subtotal = getTotalPrice();
  const discount = paymentMethod === 'ONLINE' ? subtotal * 0.02 : 0;
  const finalTotal = subtotal - discount;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const sendToWhatsApp = (orderId: string) => {
    const message = `*New Order Placed!*\n\n` +
      `*Order ID:* ${orderId}\n` +
      `*Name:* ${formData.fullName}\n` +
      `*Phone:* ${formData.phone}\n` +
      `*Address:* ${formData.address}, ${formData.city} - ${formData.pincode}\n\n` +
      `*Items:*\n${cart.map(item => `- ${item.name} ${item.sku ? `[SKU: ${item.sku}]` : ''} x ${item.quantity} (₹${item.price * item.quantity})`).join('\n')}\n\n` +
      `*Payment Method:* ${paymentMethod === 'ONLINE' ? 'Online / Paid' : 'Cash on Delivery'}\n` +
      `*Total Amount:* ₹${finalTotal.toFixed(2)}`;
    
    const whatsappUrl = `https://wa.me/917838657382?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.fullName || !formData.phone || !formData.address || !formData.city || !formData.pincode) {
      toast.error('Please fill in all shipping details!');
      return;
    }

    if (formData.phone.length < 10) {
      toast.error('Please enter a valid phone number!');
      return;
    }

    const orderId = addOrder(cart, finalTotal, formData, paymentMethod);
    setPlacedOrderId(orderId);
    setIsSuccess(true);
    
    // Save address if enabled and not already saved
    if (saveAddressEnabled) {
      const alreadySaved = user?.savedAddresses?.some(a => 
        a.address === formData.address && 
        a.pincode === formData.pincode &&
        a.fullName === formData.fullName
      );
      if (!alreadySaved) {
        addAddress(formData);
      }
    }
    
    if (paymentMethod === 'ONLINE') {
      toast.info('Order placed! Please ensure payment is completed.');
    } else {
      toast.success('Order placed successfully!');
    }
    
    // Send details to WhatsApp automatically or give button
    sendToWhatsApp(orderId);
    clearCart();
  };

  if (isSuccess) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-xl space-y-6">
          <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck size={40} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Order Placed Successfully!</h1>
            <p className="text-gray-500 text-sm">Your order has been received and is being processed.</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-xl space-y-2">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Order ID</p>
            <p className="text-xl font-bold text-brand-teal tracking-tight">{placedOrderId}</p>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => sendToWhatsApp(placedOrderId)}
              className="w-full h-12 bg-[#25D366] hover:bg-[#128C7E] text-white font-bold rounded-xl shadow-lg flex items-center justify-center space-x-2"
            >
              <span>Share Order on WhatsApp</span>
            </Button>
            <Button 
              variant="outline"
              onClick={() => navigate('/orders')}
              className="w-full h-12 border-gray-200 text-gray-700 font-bold rounded-xl"
            >
              View My Orders
            </Button>
          </div>

          <p className="text-[10px] text-gray-400 font-medium italic">
            Redirecting to WhatsApp for order confirmation...
          </p>
        </div>
      </div>
    );
  }

  const upiId = "8745974437-3@ybl";
  // Generate a unique transaction ID for security trust
  const transactionId = `TXN${Date.now()}`;
  const upiLink = `upi://pay?pa=${upiId}&pn=Mr%20MOHD%20SHADAV&am=${finalTotal.toFixed(2)}&cu=INR&tr=${transactionId}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiLink)}`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center mb-8">
        <button onClick={() => navigate('/cart')} className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Checkout</h1>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Side: Form & Payment */}
        <div className="lg:col-span-2 space-y-8">
          {/* Saved Addresses Section */}
          {user?.savedAddresses && user.savedAddresses.length > 0 && (
            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-bold text-gray-800">Saved Addresses</h2>
                <button 
                  onClick={() => setShowSavedAddresses(!showSavedAddresses)}
                  className="text-xs font-bold text-brand-pink uppercase tracking-wider"
                >
                  {showSavedAddresses ? 'Close' : 'View All'}
                </button>
              </div>

              {showSavedAddresses ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {user.savedAddresses.map((addr, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setFormData(addr);
                        setShowSavedAddresses(false);
                        toast.success('Address selected!');
                      }}
                      className={cn(
                        "p-4 rounded-xl border text-left transition-all relative group",
                        formData.address === addr.address ? "border-brand-pink bg-pink-50" : "border-gray-100 hover:border-gray-200"
                      )}
                    >
                      {formData.address === addr.address && (
                        <div className="absolute top-2 right-2 w-5 h-5 bg-brand-pink rounded-full flex items-center justify-center text-white">
                          <Check size={12} />
                        </div>
                      )}
                      <p className="text-sm font-bold text-gray-900 line-clamp-1">{addr.fullName}</p>
                      <p className="text-[10px] text-gray-500 mt-1 line-clamp-2">{addr.address}, {addr.city}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{addr.pincode}</p>
                    </button>
                  ))}
                  <button 
                    onClick={() => {
                       setFormData({ fullName: '', phone: '', address: '', city: '', pincode: '' });
                       setShowSavedAddresses(false);
                    }}
                    className="p-4 rounded-xl border border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-400 hover:text-brand-pink hover:border-brand-pink transition-all"
                  >
                    <Plus size={20} className="mb-1" />
                    <span className="text-[10px] font-bold uppercase">New Address</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl border border-gray-100">
                  <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-gray-400">
                    <MapPin size={20} />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-bold text-gray-900">
                      {user.savedAddresses.length} saved addresses found
                    </p>
                    <p className="text-[10px] text-gray-500">Quickly select a previously used address</p>
                  </div>
                  <button 
                    onClick={() => setShowSavedAddresses(true)}
                    className="px-4 py-2 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-700 hover:bg-gray-50"
                  >
                    Select
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Shipping Form */}
          <section className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm space-y-6">
            <h2 className="text-lg font-bold text-gray-800 border-b border-gray-50 pb-3">Shipping Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Full Name</label>
                <input
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="Enter your name"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-brand-pink outline-none transition-all"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Phone Number</label>
                <input
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="10-digit mobile number"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-brand-pink outline-none transition-all"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">Complete Address</label>
              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="House No, Street, Area..."
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-brand-pink outline-none transition-all min-h-[80px]"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">City</label>
                <input
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  placeholder="Enter city"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-brand-pink outline-none transition-all"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Pincode</label>
                <input
                  name="pincode"
                  value={formData.pincode}
                  onChange={handleChange}
                  placeholder="6-digit pincode"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-brand-pink outline-none transition-all"
                  required
                />
              </div>
            </div>

            <div className="pt-4 border-t border-gray-50">
              <label className="flex items-center gap-3 cursor-pointer group">
                <div className="relative">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={saveAddressEnabled}
                    onChange={(e) => setSaveAddressEnabled(e.target.checked)}
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:bg-brand-pink transition-colors"></div>
                  <div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full transition-transform peer-checked:translate-x-5"></div>
                </div>
                <span className="text-xs font-bold text-gray-600 group-hover:text-gray-900 transition-colors">Save this address for future orders</span>
              </label>
            </div>
          </section>

          {/* Payment Selection */}
          <section className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm space-y-6">
            <h2 className="text-lg font-bold text-gray-800 border-b border-gray-50 pb-3">Select Payment Method</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setPaymentMethod('COD')}
                className={`p-4 border rounded-xl flex flex-col items-center justify-center space-y-2 transition-all ${
                  paymentMethod === 'COD' 
                    ? 'border-brand-pink bg-pink-50 ring-1 ring-brand-pink' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <span className="font-bold text-gray-800">Cash on Delivery</span>
                <span className="text-[10px] text-gray-500 uppercase tracking-tight">Pay when you get it</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('ONLINE')}
                className={`p-4 border rounded-xl flex flex-col items-center justify-center space-y-2 transition-all relative overflow-hidden ${
                  paymentMethod === 'ONLINE' 
                    ? 'border-brand-pink bg-pink-50 ring-1 ring-brand-pink' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="absolute top-0 right-0 bg-brand-pink text-white text-[8px] font-bold px-2 py-0.5 rounded-bl">
                  2% OFF
                </div>
                <span className="font-bold text-gray-800">Online Payment / UPI</span>
                <span className="text-[10px] text-brand-pink font-bold uppercase tracking-tight">Extra 2% Discount</span>
              </button>
            </div>

            {paymentMethod === 'ONLINE' && (
              <div className="mt-6 space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                {/* Tabs for Online Payment */}
                <div className="flex border-b border-gray-100">
                  <button 
                    onClick={() => setOnlineTab('QR')}
                    className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-wider transition-all border-b-2 ${
                      onlineTab === 'QR' ? 'border-brand-pink text-brand-pink' : 'border-transparent text-gray-400'
                    }`}
                  >
                    Scan QR Code
                  </button>
                  <button 
                    onClick={() => setOnlineTab('APP')}
                    className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-wider transition-all border-b-2 ${
                      onlineTab === 'APP' ? 'border-brand-pink text-brand-pink' : 'border-transparent text-gray-400'
                    }`}
                  >
                    UPI Apps (PhonePe/GPay)
                  </button>
                </div>

                <div className="p-6 bg-gray-50 rounded-xl border border-dashed border-gray-300 flex flex-col items-center text-center">
                  {onlineTab === 'QR' ? (
                    <>
                      <p className="text-[10px] font-bold text-gray-600 mb-4 uppercase tracking-wider">Scan QR and Pay</p>
                      <div className="bg-white p-4 rounded-xl shadow-md mb-4 border border-gray-100">
                        <img src={qrUrl} alt="UPI QR Code" className="w-40 h-40" />
                      </div>
                    </>
                  ) : (
                    <div className="w-full space-y-4">
                      <p className="text-[10px] font-bold text-gray-600 mb-4 uppercase tracking-wider">Choose your app</p>
                      <div className="grid grid-cols-2 gap-4">
                        <a 
                          href={upiLink}
                          className="flex flex-col items-center p-4 bg-white rounded-xl border border-gray-100 shadow-sm hover:border-brand-pink transition-all group"
                        >
                          <div className="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                            <span className="text-purple-600 font-bold text-base">P</span>
                          </div>
                          <span className="text-[10px] font-bold text-gray-700">PhonePe</span>
                        </a>
                        <a 
                          href={upiLink}
                          className="flex flex-col items-center p-4 bg-white rounded-xl border border-gray-100 shadow-sm hover:border-brand-pink transition-all group"
                        >
                          <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                            <span className="text-blue-600 font-bold text-base">G</span>
                          </div>
                          <span className="text-[10px] font-bold text-gray-700">Google Pay</span>
                        </a>
                      </div>
                      <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 text-left">
                        <p className="text-[9px] text-blue-700 font-bold leading-tight">
                          Note: If you see a "Security Decline" error in PhonePe, please use the "Scan QR Code" tab instead. QR payments are 100% secure.
                        </p>
                      </div>
                      <p className="text-[9px] text-gray-400 font-medium leading-tight">Works on mobile devices with UPI apps installed.</p>
                    </div>
                  )}
                  
                  <div className="space-y-1 mt-4">
                    <p className="text-sm font-bold text-gray-800">{upiId}</p>
                    <p className="text-[10px] text-gray-400 font-bold italic">Payable Amount: ₹{finalTotal.toFixed(2)}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="pt-4 border-t border-gray-50 flex items-center space-x-2 text-brand-teal">
              <ShieldCheck size={20} />
              <span className="text-xs font-bold uppercase tracking-wider">Secure SSL Encrypted Checkout</span>
            </div>
          </section>
        </div>

        {/* Summary Side */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm sticky top-24">
            <h3 className="font-bold text-gray-900 mb-6 border-b border-gray-50 pb-4 uppercase tracking-tight text-sm">Order Summary</h3>
            
            <div className="space-y-4 mb-6 text-sm">
              {cart.map(item => (
                <div key={item.id} className="flex justify-between items-center">
                  <span className="text-gray-500 line-clamp-1 flex-1 mr-4">{item.name} × {item.quantity}</span>
                  <span className="font-medium text-gray-900">₹{item.price * item.quantity}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-4 border-t border-gray-50 mb-6">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Subtotal</span>
                <span>₹{subtotal}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm text-brand-pink font-medium">
                  <span>Online Discount (2%)</span>
                  <span>-₹{discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-lg font-bold text-gray-900 pt-2">
                <span>Final Total</span>
                <span>₹{finalTotal.toFixed(2)}</span>
              </div>
            </div>

            <Button 
               onClick={handleSubmit}
               className={`w-full h-12 text-white font-bold rounded-lg shadow-lg transition-all ${
                 paymentMethod === 'ONLINE' 
                  ? 'bg-brand-pink shadow-brand-pink/20' 
                  : 'bg-brand-teal shadow-brand-teal/20 hover:bg-brand-teal/90'
               }`}
            >
              {paymentMethod === 'ONLINE' ? 'Pay & Confirm Order' : 'Confirm Order (COD)'}
            </Button>
            
            <p className="text-center text-[9px] text-gray-400 mt-4 font-bold uppercase tracking-widest leading-relaxed">
              By placing this order, you agree to our <br/> Terms and Conditions
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
