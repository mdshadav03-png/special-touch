import { useWishlistStore } from '../store/useWishlistStore';
import { ProductCard } from '../components/ProductCard';
import { Heart, ArrowLeft, ShoppingBag } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';

export function WishlistPage() {
  const { wishlist } = useWishlistStore();
  const navigate = useNavigate();

  if (wishlist.length === 0) {
    return (
      <div className="bg-white min-h-screen">
        <div className="flex items-center p-4 border-b border-gray-100">
           <button onClick={() => navigate(-1)} className="mr-4"><ArrowLeft size={20} /></button>
           <h1 className="text-lg font-bold text-gray-800 uppercase">MY WISHLIST</h1>
        </div>
        <div className="max-w-7xl mx-auto px-4 py-20 text-center flex flex-col items-center">
          <div className="relative w-48 h-48 bg-pink-50 rounded-full flex items-center justify-center mb-6 overflow-hidden">
             <Heart size={64} className="text-brand-pink opacity-20" />
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Your wishlist is empty</h2>
          <p className="text-gray-500 mb-8 max-w-xs">Save items that you like in your wishlist with a single tap.</p>
          <Link 
            to="/" 
            className="w-full max-w-xs py-3 bg-brand-pink text-white font-bold rounded-lg shadow-lg shadow-brand-pink/20 transition-all hover:bg-brand-pink/90"
          >
            Go Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      <div className="bg-white px-4 py-4 border-b border-gray-100 sticky top-0 sm:static z-10">
        <div className="flex items-center">
           <button onClick={() => navigate(-1)} className="mr-4"><ArrowLeft size={20} /></button>
           <h1 className="text-lg font-bold text-gray-800 uppercase tracking-tight">MY WISHLIST ({wishlist.length})</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {wishlist.map((product) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              key={product.id}
            >
              <ProductCard product={product} />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
