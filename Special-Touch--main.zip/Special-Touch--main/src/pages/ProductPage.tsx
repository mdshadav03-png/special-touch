import { useParams, useNavigate } from 'react-router-dom';
import { PRODUCTS } from '../data/products';
import { useCartStore } from '../store/useCartStore';
import { useWishlistStore } from '../store/useWishlistStore';
import { Star, ShieldCheck, Truck, RotateCcw, Share2, Heart, ShoppingBag, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import { Button } from '../components/ui/button';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { SafeImage } from '../components/SafeImage';
import { ProductReviews } from '../components/ProductReviews';
import { useReviewStore } from '../store/useReviewStore';

export function ProductPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = PRODUCTS.find((p) => p.id === id);
  const addToCart = useCartStore((state) => state.addToCart);
  const { toggleWishlist, isInWishlist } = useWishlistStore();
  const getAverageRating = useReviewStore((state) => state.getAverageRating);
  
  const [activeImage, setActiveImage] = useState(0);

  if (!product) {
    return <div className="text-center py-20">Product not found</div>;
  }

  const isWishlisted = isInWishlist(product.id);
  const { rating, count } = getAverageRating(product.id, product.rating, product.reviews);

  const handleAddToCart = () => {
    addToCart(product);
    toast.success('Added to cart!');
  };

  const handleBuyNow = () => {
    addToCart(product);
    navigate('/cart');
  };

  return (
    <div className="pb-20 sm:pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left: Images */}
          <div className="space-y-4">
            <div className="h-[280px] sm:h-auto sm:aspect-[4/5] bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={product.images[activeImage]}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full h-full"
                >
                  <SafeImage
                    src={product.images[activeImage]}
                    alt={product.name}
                    loading="eager"
                    className="w-full h-full object-contain"
                  />
                </motion.div>
              </AnimatePresence>
            </div>
            <div className="grid grid-cols-4 gap-2 sm:gap-4 px-1 sm:px-0">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(idx)}
                  className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                    activeImage === idx ? 'border-brand-pink' : 'border-transparent'
                  }`}
                >
                  <SafeImage src={img} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Right: Info */}
          <div className="space-y-4 sm:space-y-6">
            <div>
              <h1 className="text-lg sm:text-3xl font-heading text-gray-900 mb-1 leading-tight">{product.name}</h1>
              <div className="flex items-center space-x-3">
                <div className="bg-brand-teal text-white flex items-center px-1.5 py-0.5 rounded text-[10px] sm:text-sm font-bold">
                  {rating} <Star size={10} className="ml-1 fill-white" />
                </div>
                <span className="text-gray-400 text-[10px] sm:text-sm uppercase tracking-wider font-bold">{count.toLocaleString()} Reviews</span>
              </div>
            </div>

            <div className="flex items-baseline space-x-3">
              <span className="text-2xl sm:text-4xl font-bold text-gray-900">₹{product.price}</span>
              <div className="flex items-center space-x-2">
                <span className="text-xs sm:text-lg text-gray-400 line-through">₹{product.originalPrice}</span>
                <span className="text-brand-pink font-bold text-xs sm:text-base">{product.discount}% OFF</span>
              </div>
            </div>

            <p className="text-gray-600 leading-relaxed text-xs sm:text-base line-clamp-3 sm:line-clamp-none">
              {product.description}
            </p>

            {(product.sku || product.color) && (
              <div className="flex flex-wrap gap-4 pt-2">
                {product.sku && (
                  <div className="bg-gray-100 px-3 py-1.5 rounded-lg">
                    <span className="text-[10px] sm:text-xs font-bold text-gray-400 uppercase block leading-none mb-1">SKU ID</span>
                    <span className="text-xs sm:text-sm font-mono font-bold text-gray-700">{product.sku}</span>
                  </div>
                )}
                {product.color && (
                  <div className="bg-gray-100 px-3 py-1.5 rounded-lg">
                    <span className="text-[10px] sm:text-xs font-bold text-gray-400 uppercase block leading-none mb-1">Color</span>
                    <span className="text-xs sm:text-sm font-bold text-gray-700">{product.color}</span>
                  </div>
                )}
              </div>
            )}

            {/* Desktop Action Buttons (Visible only on larger screens) */}
            <div className="hidden sm:grid grid-cols-2 gap-4">
               <Button
                  variant="outline"
                  size="lg"
                  onClick={handleAddToCart}
                  className="h-14 rounded-lg border-2 border-brand-pink text-brand-pink hover:bg-brand-pink/5 font-bold"
               >
                  <ShoppingCart className="mr-2" size={18} /> Add to Cart
               </Button>
               <Button
                  size="lg"
                  onClick={handleBuyNow}
                  className="h-14 rounded-lg bg-brand-pink hover:bg-brand-pink/90 text-white font-bold"
               >
                  <ShoppingBag className="mr-2" size={18} /> Buy Now
               </Button>
            </div>

            <div className="border-t border-b border-gray-100 py-6 space-y-4">
              <h3 className="font-bold text-gray-900">Special Highlights</h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 uppercase tracking-wider text-[10px] font-bold text-gray-500">
                 {product.features.map((feature, i) => (
                   <li key={i} className="flex items-center">
                     <div className="w-1 h-1 bg-brand-pink rounded-full mr-2"></div>
                     {feature}
                   </li>
                 ))}
              </ul>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="flex flex-col items-center text-center p-4 bg-gray-50 rounded-xl">
                <Truck size={24} className="text-gray-600 mb-2" />
                <span className="text-[10px] font-bold text-gray-800 uppercase">Free Delivery</span>
              </div>
              <div className="flex flex-col items-center text-center p-4 bg-gray-50 rounded-xl">
                <ShieldCheck size={24} className="text-gray-600 mb-2" />
                <span className="text-[10px] font-bold text-gray-800 uppercase">Cash On Delivery</span>
              </div>
              <div className="flex flex-col items-center text-center p-4 bg-gray-50 rounded-xl">
                <RotateCcw size={24} className="text-gray-600 mb-2" />
                <span className="text-[10px] font-bold text-gray-800 uppercase">7-Day Returns</span>
              </div>
            </div>

            <div className="flex space-x-3 pt-4">
               <button 
                  onClick={() => toggleWishlist(product)}
                  className={`flex-1 border rounded-lg py-2 flex items-center justify-center text-sm font-medium transition-all ${
                    isWishlisted 
                      ? 'border-brand-pink bg-pink-50 text-brand-pink' 
                      : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
               >
                 <Heart size={18} className={`mr-2 ${isWishlisted ? 'fill-brand-pink text-brand-pink' : 'text-gray-400'}`} /> 
                 {isWishlisted ? 'Wishlisted' : 'Wishlist'}
               </button>
               <button className="flex-1 border border-gray-200 rounded-lg py-2 flex items-center justify-center text-sm font-medium hover:bg-gray-50">
                 <Share2 size={18} className="mr-2 text-gray-400" /> Share
               </button>
            </div>
          </div>
        </div>

        {/* Detailed Reviews Section */}
        <ProductReviews productId={product.id} />
      </div>

      {/* Sticky Bottom Bar for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-4 sm:hidden z-50 shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            onClick={handleAddToCart}
            className="h-12 rounded-xl border-gray-200 text-gray-700 font-bold text-sm"
          >
            <ShoppingCart className="mr-2" size={18} /> Add to Cart
          </Button>
          <Button
            onClick={handleBuyNow}
            className="h-12 rounded-xl bg-brand-pink hover:bg-brand-pink/90 text-white font-bold text-sm shadow-lg shadow-brand-pink/20"
          >
            <ShoppingBag className="mr-2" size={18} /> Buy Now
          </Button>
        </div>
      </div>
    </div>
  );
}
