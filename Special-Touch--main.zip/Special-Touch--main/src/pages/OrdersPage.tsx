import { useOrderStore } from '../store/useOrderStore';
import { Search, SlidersHorizontal, ChevronRight, Star, ArrowLeft, Package, Truck, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { SafeImage } from '../components/SafeImage';
import { useState } from 'react';
import { OrderTracker } from '../components/OrderTracker';
import { toast } from 'sonner';
import { cn } from '../lib/utils';

export function OrdersPage() {
  const { orders, updateOrderStatus } = useOrderStore();
  const navigate = useNavigate();
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  const simulateUpdate = (orderId: string, currentStatus: string) => {
    switch (currentStatus) {
      case 'Processing':
        updateOrderStatus(orderId, 'Shipped', 'Regional Sorting Facility', 'Your order has been sorted and is ready for dispatch.');
        toast.info('Order status updated: Shipped');
        break;
      case 'Shipped':
        updateOrderStatus(orderId, 'Out for Delivery', 'Local HUB - Delhi', 'Your order is out for delivery with our courier partner.');
        toast.info('Order status updated: Out for Delivery');
        break;
      case 'Out for Delivery':
        updateOrderStatus(orderId, 'Delivered', 'Recipient Address', 'Order delivered successfully to the recipient.');
        toast.success('Order status updated: Delivered');
        break;
      default:
        toast.error('Order is already in final state.');
    }
  };

  if (orders.length === 0) {
    return (
      <div className="bg-white min-h-screen">
        <div className="flex items-center p-4 border-b border-gray-100">
           <button onClick={() => navigate(-1)} className="mr-4"><ArrowLeft size={20} /></button>
           <h1 className="text-lg font-bold text-gray-800 uppercase">MY ORDERS</h1>
        </div>
        <div className="max-w-7xl mx-auto px-4 py-20 text-center flex flex-col items-center">
          <div className="relative w-48 h-48 bg-pink-50 rounded-full flex items-center justify-center mb-6 overflow-hidden">
             <SafeImage 
              src="https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=400" 
              className="w-full h-full object-cover opacity-60" 
              alt="Empty orders"
             />
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">No orders placed</h2>
          <p className="text-gray-500 mb-8 max-w-xs">You haven't ordered anything yet. Go to home to see trending products.</p>
          <Link 
            to="/" 
            className="w-full max-w-xs py-3 bg-brand-pink text-white font-bold rounded-lg shadow-lg shadow-brand-pink/20 transition-all hover:bg-brand-pink/90"
          >
            Start Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Header bar */}
      <div className="bg-white px-4 py-4 border-b border-gray-100 sticky top-0 sm:static z-10 shadow-sm">
        <div className="flex items-center mb-4">
           <button onClick={() => navigate(-1)} className="mr-4"><ArrowLeft size={20} /></button>
           <h1 className="text-lg font-bold text-gray-800 uppercase tracking-tight">MY ORDERS</h1>
        </div>
        
        <div className="flex items-center space-x-3">
           <div className="relative flex-1">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
             <input 
              type="text" 
              placeholder="Search orders" 
              className="w-full bg-white border border-gray-200 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-brand-pink transition-all"
             />
           </div>
           <button className="flex items-center space-x-1 text-xs font-bold text-gray-600 bg-gray-50 px-3 py-2.5 rounded-lg border border-gray-200 transition-colors">
             <SlidersHorizontal size={14} />
             <span className="uppercase">Filters</span>
           </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto space-y-2 pt-2">
        {orders.map((order) => (
          <div 
            key={order.id}
            className="bg-white border-b border-gray-100 mb-2 shadow-sm overflow-hidden"
          >
            <div className="p-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] sm:text-xs font-bold text-gray-400">Order #{order.id}</span>
                <span className={cn(
                  "text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider",
                  order.status === 'Processing' ? 'bg-blue-50 text-blue-600' :
                  order.status === 'Shipped' ? 'bg-orange-50 text-orange-600' :
                  order.status === 'Out for Delivery' ? 'bg-purple-50 text-purple-600' :
                  'bg-green-50 text-green-600'
                )}>
                  {order.status}
                </span>
              </div>

              {order.items.map((item) => (
                <div key={item.id} className="flex space-x-4 mb-4">
                  <div className="w-16 h-20 bg-gray-50 rounded overflow-hidden shrink-0 border border-gray-100">
                    <SafeImage src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 flex flex-col py-0.5">
                    <div className="flex justify-between items-start">
                      <h3 className="text-sm font-bold text-gray-900 group-hover:text-brand-pink line-clamp-1">
                        {item.name}
                      </h3>
                    </div>
                    <div className="flex items-center text-[10px] font-medium text-gray-500 space-x-2 mt-1">
                       <span>Qty: {item.quantity}</span>
                       <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                       <span>₹{item.price.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))}

              <div className="flex items-center justify-between pt-2 border-t border-gray-50 mt-2">
                <div className="flex items-center space-x-2">
                   <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                     order.paymentMethod === 'ONLINE' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-orange-100 text-orange-700'
                   }`}>
                     {order.paymentMethod}
                   </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  {order.status !== 'Delivered' && (
                    <button 
                      onClick={() => simulateUpdate(order.id, order.status)}
                      className="text-[10px] font-bold text-blue-600 hover:underline"
                    >
                      Update Status
                    </button>
                  )}
                  <button 
                    onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                    className="flex items-center text-[10px] sm:text-xs font-bold text-brand-pink uppercase tracking-tight"
                  >
                    {expandedOrder === order.id ? 'Hide Tracking' : 'Track Order'}
                    <ChevronRight size={14} className={cn("ml-0.5 transition-transform", expandedOrder === order.id && "rotate-90")} />
                  </button>
                </div>
              </div>
            </div>

            <AnimatePresence>
              {expandedOrder === order.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="bg-gray-50 border-t border-gray-100 overflow-hidden"
                >
                  <OrderTracker order={order} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}

        {/* Motivational Banner at bottom */}
        <div className="py-12 flex flex-col items-center bg-gray-100/50 mt-10 rounded-t-3xl border-t border-gray-100">
           <div className="flex flex-col items-center text-center space-y-1 mb-8">
              <h3 className="text-2xl font-bold text-gray-800">All Izzz Well</h3>
              <p className="text-gray-400 font-medium italic">Just keep shopping</p>
           </div>
           <div className="relative w-48 h-48 sm:w-64 sm:h-64 bg-white rounded-full flex items-center justify-center overflow-hidden shadow-xl shadow-pink-100 border-4 border-white">
              <SafeImage 
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400" 
                alt="Woman shopping" 
                className="w-full h-full object-cover"
              />
           </div>
        </div>
      </div>
    </div>
  );
}
