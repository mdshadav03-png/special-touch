import { PRODUCTS, CATEGORIES } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { motion } from 'motion/react';
import { ChevronRight, ArrowRight, ListFilter } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { SafeImage } from '../components/SafeImage';
import { useState, useMemo } from 'react';

type SortOption = 'default' | 'price-low' | 'price-high' | 'popularity' | 'newest';

export function HomePage() {
  const { name } = useParams();
  const [sortBy, setSortBy] = useState<SortOption>('default');
  
  const sortedProducts = useMemo(() => {
    let products = name 
      ? PRODUCTS.filter(p => p.category.toLowerCase() === name.toLowerCase())
      : [...PRODUCTS];

    switch (sortBy) {
      case 'price-low':
        return products.sort((a, b) => a.price - b.price);
      case 'price-high':
        return products.sort((a, b) => b.price - a.price);
      case 'popularity':
        // Calculate a basic popularity score based on reviews and rating
        return products.sort((a, b) => (b.reviews * b.rating) - (a.reviews * a.rating));
      case 'newest':
        // Show isNewArrival products first, then by index (presuming newer are later in array)
        return products.sort((a, b) => {
          if (a.isNewArrival && !b.isNewArrival) return -1;
          if (!a.isNewArrival && b.isNewArrival) return 1;
          return 0;
        });
      default:
        return products;
    }
  }, [name, sortBy]);

  return (
    <div className="pb-12">
      {/* Hero Banner */}
      <section className="relative min-h-[350px] sm:h-[400px] md:h-[500px] bg-[#fdf2f4] overflow-hidden mb-8 sm:mb-12 py-8 sm:py-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-md"
          >
            <span className="inline-block px-3 py-1 bg-brand-pink text-white text-[10px] font-bold rounded-full mb-3 sm:mb-4">NEW COLLECTION 2026</span>
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-heading text-gray-900 leading-tight mb-4 sm:mb-6">
              Carry Your <span className="text-brand-pink">Elegance</span> with Pride.
            </h1>
            <p className="text-gray-600 text-sm sm:text-base mb-6 sm:mb-8 max-w-sm">
              Discover our exclusive range of handcrafted ethnic purses and modern designer handbags.
            </p>
            <Link to="/category/Handbags">
              <button className="bg-brand-pink text-white px-6 sm:px-8 py-2.5 sm:py-3 rounded-md font-bold flex items-center group shadow-lg shadow-brand-pink/20 hover:bg-brand-pink/90 transition-all text-sm sm:text-base">
                Shop Now
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
              </button>
            </Link>
          </motion.div>
        </div>
        
        {/* Abstract background blobs */}
        <div className="absolute top-0 right-0 w-1/2 h-full hidden lg:block">
           <SafeImage 
            src="https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=800" 
            alt="Handbag" 
            loading="eager"
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[500px] object-contain drop-shadow-2xl rotate-6 bg-transparent" 
           />
        </div>
        <div className="absolute top-1/2 right-[10%] w-64 h-64 bg-brand-pink/10 rounded-full blur-3xl -translate-y-1/2"></div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Categories Bar */}
        <section className="mb-12 overflow-x-auto no-scrollbar py-2">
          <div className="flex space-x-6 sm:space-x-10 min-w-max px-2">
            {CATEGORIES.map((cat) => (
              <Link key={cat.id} to={`/category/${cat.name}`} className="flex flex-col items-center group">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gray-50 rounded-full flex items-center justify-center border-2 border-transparent group-hover:border-brand-pink group-hover:bg-brand-pink/5 transition-all mb-2 overflow-hidden p-2">
                  <SafeImage 
                    src={PRODUCTS.find(p => p.category === cat.name)?.images[0] || 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=200'} 
                    className="w-full h-full object-contain group-hover:scale-110 transition-transform bg-transparent" 
                    alt={cat.name}
                  />
                </div>
                <span className="text-[10px] sm:text-xs font-semibold text-gray-700 group-hover:text-brand-pink">{cat.name}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Section */}
        <section className="mb-12">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-heading text-gray-900 mb-2">
                {name ? `${name} Collection` : 'Trending Collections'}
              </h2>
              <p className="text-gray-500 text-sm">
                {name ? `Explore our finest ${name.toLowerCase()}` : 'Our most popular designs this week'}
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="relative inline-block">
                <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-lg px-3 py-2 hover:border-brand-pink transition-colors cursor-pointer group">
                  <ListFilter size={16} className="text-gray-500 group-hover:text-brand-pink" />
                  <select 
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="appearance-none bg-transparent text-sm font-semibold text-gray-700 outline-none pr-6 cursor-pointer"
                  >
                    <option value="default">Relevance</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                    <option value="popularity">Popularity</option>
                    <option value="newest">New Arrivals</option>
                  </select>
                  <div className="absolute right-3 pointer-events-none">
                    <ChevronRight size={14} className="rotate-90 text-gray-400" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
            {sortedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Trust Banner */}
        <section className="bg-gray-900 rounded-2xl p-8 sm:p-12 text-white relative overflow-hidden mb-12">
          <div className="relative z-10 grid md:grid-cols-3 gap-8">
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold mb-2">Quality Assured</h3>
              <p className="text-gray-400 text-sm">Every bag undergoes strict quality checks before shipping.</p>
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold mb-2">Safe Payments</h3>
              <p className="text-gray-400 text-sm">Multiple secure payment options including COD and UPI.</p>
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold mb-2">Easy Returns</h3>
              <p className="text-gray-400 text-sm">Not satisfied? Return within 7 days for a full refund.</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
