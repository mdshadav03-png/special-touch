import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: 'purse-001',
    name: 'Ethnic Floral Embroidered Handbag - Beige',
    description: 'Beautifully handcrafted beige handbag with vibrant multi-color floral embroidery. Perfect for ethnic occasions and daily style.',
    price: 899,
    originalPrice: 1599,
    discount: 43,
    category: 'Handbags',
    rating: 4.8,
    reviews: 1240,
    images: [
      'https://images.unsplash.com/photo-1621644778103-6089304729f2?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Premium Suede Finish', 'Durable Handles', 'Spacious Compartments', 'Inner Zip Pocket'],
    sku: 'HB-FL-BG-001',
    color: 'Beige',
    isBestSeller: true,
    isNewArrival: true
  },
  {
    id: 'purse-002',
    name: 'Royal White Designer Party Bag',
    description: 'Elegant white handbag featuring intricate traditional designs. Adds a touch of royalty to your outfit.',
    price: 949,
    originalPrice: 1799,
    discount: 47,
    category: 'Handbags',
    rating: 4.7,
    reviews: 856,
    images: [
      'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Exquisite Fabric', 'Golden Accents', 'Detachable Belt', 'Dimension: 29x25x14 cm'],
    isNewArrival: true
  },
  {
    id: 'clutch-001',
    name: 'Golden Bloom Party Clutch',
    description: 'A sparkling golden clutch with delicate beadwork. Ideal for weddings and parties.',
    price: 599,
    originalPrice: 999,
    discount: 40,
    category: 'Clutches',
    rating: 4.9,
    reviews: 312,
    images: [
      'https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1566150905458-1bf1fd15dbc4?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Compact Design', 'Safe Locking Mechanism', 'Premium Lining'],
  },
  {
    id: 'sling-001',
    name: 'Urban Chic Mini Sling Bag',
    description: 'A trendy mini sling bag for those on the go. Compact yet spacious enough for essentials.',
    price: 499,
    originalPrice: 799,
    discount: 37,
    category: 'Sling Bags',
    rating: 4.6,
    reviews: 185,
    images: [
      'https://images.unsplash.com/photo-1566150905458-1bf1fd15dbc4?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Adjustable Strap', 'Lightweight', 'Water Resistant'],
  },
  {
    id: 'tote-001',
    name: 'Everyday Canvas Premium Tote',
    description: 'Rugged yet stylish canvas tote. Your perfect companion for grocery runs or office days.',
    price: 699,
    originalPrice: 1199,
    discount: 42,
    category: 'Totes',
    rating: 4.4,
    reviews: 98,
    images: [
      'https://images.unsplash.com/photo-1544816153-0973059430cf?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1598033129183-c4f50c7176c8?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Spacious', 'Eco-friendly', 'Strong Handles'],
  },
  {
    id: 'purse-004',
    name: 'Midnight Black Luxury Handbag',
    description: 'Sophisticated black bag with contrasting accents. Stand out in every crowd.',
    price: 999,
    originalPrice: 1999,
    discount: 50,
    category: 'Handbags',
    rating: 4.9,
    reviews: 2100,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Jet Black Base', 'High Tension Stitching', 'Premium Lining', 'Adjustable Shoulder Strap'],
    isBestSeller: true
  },
  {
    id: 'wallet-001',
    name: 'Olive Verve Luxury Leather Wallet',
    description: '100% Top-Grain Calf Leather with quilted elegance. Features 3 secure zipped pockets and a dedicated coin pouch for ultimate function.',
    price: 699,
    originalPrice: 1299,
    discount: 46,
    category: 'Wallets',
    rating: 4.9,
    reviews: 450,
    images: [
      'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1601340498197-036109968a3e?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['100% Top-Grain Leather', '3 Zipped Pockets', 'Quilted Design', 'External Easy-Access Pocket'],
    isBestSeller: true
  },
  {
    id: 'wallet-002',
    name: 'Chevron Aesthetic Maroon Wallet',
    description: 'Sleek chevron patterns and gold clasp create an unmatched elegant look. Perfect for adding a touch of style to your daily routine.',
    price: 699,
    originalPrice: 1199,
    discount: 42,
    category: 'Wallets',
    rating: 4.8,
    reviews: 320,
    images: [
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Premium Polished Leather', 'Gold Hardware', 'Multiple Card Slots', 'Elegant Chevron Stitching'],
  },
  {
    id: 'wallet-003',
    name: 'Organized Elegance Dark Brown Wallet',
    description: 'Ample space for 12+ cards, cash, and a convenient ID holder. The perfect blend of style and function for the modern lifestyle.',
    price: 699,
    originalPrice: 1099,
    discount: 36,
    category: 'Wallets',
    rating: 4.7,
    reviews: 280,
    images: [
      'https://images.unsplash.com/photo-1601340498197-036109968a3e?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1606170033648-5d55a3edf314?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['12+ Card Slots', 'ID Holder Section', 'Bill Compartments', 'Secure Magnetic Closure'],
  },
  {
    id: 'clutch-002',
    name: 'Essential Tan Refined Clutch',
    description: 'The essential clutch for refined style and organization. Discover the perfect blend of function and elegance for your everyday needs.',
    price: 699,
    originalPrice: 999,
    discount: 30,
    category: 'Clutches',
    rating: 4.6,
    reviews: 150,
    images: [
      'https://images.unsplash.com/photo-1566150905458-1bf1fd15dbc4?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Refined Design', 'Spacious Interior', 'Back View Details', 'Quick-Access Zipped Pocket'],
  },
  {
    id: 'handbag-001',
    name: 'Premium Designer Handbag - Tan Brown',
    description: 'Versatile and stylish tan handbag with golden hardware. Includes adjustable shoulder strap and multiple compartments.',
    price: 699,
    originalPrice: 1499,
    discount: 53,
    category: 'Handbags',
    rating: 4.9,
    reviews: 1200,
    images: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['31x25x16 cm Dimensions', 'Golden Metal Accents', 'Long Shoulder Strap', 'Premium Faux Leather'],
    isBestSeller: true
  },
  {
    id: 'handbag-002',
    name: 'Premium Designer Handbag - Olive Green',
    description: 'Chic olive green handbag featuring a sophisticated texture and gold-plated hardware. A perfect accessory for work or evening events.',
    price: 699,
    originalPrice: 1499,
    discount: 53,
    category: 'Handbags',
    rating: 4.8,
    reviews: 950,
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['31x25x16 cm Dimensions', 'Elegant Green Tone', 'Sturdy Gold Handles', 'Spacious Compartments'],
  },
  {
    id: 'handbag-003',
    name: 'Premium Designer Handbag - Deep Rose',
    description: 'Beautiful deep rose pink handbag that combines femininity with functionality. Soft touch finish with premium details.',
    price: 699,
    originalPrice: 1499,
    discount: 53,
    category: 'Handbags',
    rating: 4.7,
    reviews: 780,
    images: [
      'https://images.unsplash.com/photo-1564415051542-cb8452445c91?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['31x25x16 cm Dimensions', 'Rose Pink Finish', 'Adjustable Sling Strap', 'Durable Lining'],
  },
  {
    id: 'handbag-004',
    name: 'Premium Designer Handbag - Coffee Brown',
    description: 'Rich coffee brown handbag with a professional and timeless appeal. Crafted with high-quality materials for daily durability.',
    price: 699,
    originalPrice: 1499,
    discount: 53,
    category: 'Handbags',
    rating: 4.8,
    reviews: 640,
    images: [
      'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['31x25x16 cm Dimensions', 'Classic Coffee Brown', 'Multiple Utility Pockets', 'Premium Hardened Base'],
  },
  {
    id: 'handbag-005',
    name: 'Legacy Multi-Color Embroidered Handbag',
    description: 'A masterpiece of traditional craftsmanship featuring vibrant multi-color embroidery on premium fabric. Designed for the modern woman who loves ethnic elegance with a spacious interior for all daily essentials.',
    price: 1299,
    originalPrice: 2499,
    discount: 48,
    category: 'Handbags',
    rating: 4.9,
    reviews: 256,
    images: [
      'https://images.unsplash.com/photo-1621644778103-6089304729f2?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=1000'
    ],
    features: [
      'Dimensions: 33 cm x 11 cm x 23 cm',
      '1 Main Compartment with Inner Zip Pocket',
      '2 Interior Open Pockets for organization',
      'Premium Fabric with Smooth Zipper',
      'Spacious Interior for Daily Essentials'
    ],
    isNewArrival: true,
    isBestSeller: true
  },
  {
    id: 'purse-005',
    name: 'Floral Embroidered Slim Wallet',
    description: 'A beautiful handcrafted slim wallet featuring vibrant ethnic floral embroidery. Compact yet spacious enough for your cards, cash, and small essentials.',
    price: 199,
    originalPrice: 499,
    discount: 60,
    category: 'Purses',
    rating: 4.7,
    reviews: 124,
    images: [
      'https://i.ibb.co/3YzpFL6X/Whats-App-Image-2026-04-12-at-8-45-08-PM-1-1.jpg',
      'https://i.ibb.co/8LHW94Bn/Whats-App-Image-2026-04-12-at-8-45-08-PM-2-25.jpg'
    ],
    features: [
      'Traditional Multi-color Floral Embroidery',
      'Slim & Compact Profile',
      'Premium Zip-around Closure',
      'Durable Fabric Construction'
    ],
    sku: 'WL-FL-MC-005',
    color: 'Multi-color',
    isNewArrival: true
  }
];

export const CATEGORIES = [
  { id: '1', name: 'Handbags', icon: 'ShoppingBag' },
  { id: '2', name: 'Clutches', icon: 'Wallet' },
  { id: '3', name: 'Sling Bags', icon: 'Briefcase' },
  { id: '4', name: 'Wallets', icon: 'CreditCard' },
  { id: '5', name: 'Totes', icon: 'BaggageClaim' },
];
